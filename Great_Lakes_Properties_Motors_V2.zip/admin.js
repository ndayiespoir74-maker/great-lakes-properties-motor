window.DEFAULT_LISTINGS = [{"id": "demo-1", "title": "Modern 2-Bedroom Apartment", "category": "Apartment", "purpose": "For Rent", "price": 450000, "currency": "RWF", "location": "Gisenyi, Rubavu", "details": "Demo listing \u2014 replace with your real apartment details.", "photo": "", "featured": true, "created": 1776800000000}, {"id": "demo-2", "title": "Family House", "category": "House", "purpose": "For Sale", "price": 85000000, "currency": "RWF", "location": "Rubavu", "details": "Demo listing \u2014 replace with your real house details.", "photo": "", "featured": false, "created": 1776700000000}, {"id": "demo-3", "title": "Residential Land Plot", "category": "Land", "purpose": "For Sale", "price": 18000000, "currency": "RWF", "location": "Rubavu", "details": "Demo listing \u2014 replace with your actual plot size and location.", "photo": "", "featured": true, "created": 1776600000000}, {"id": "demo-4", "title": "Toyota SUV", "category": "Car", "purpose": "For Sale", "price": 35000000, "currency": "RWF", "location": "Rubavu", "details": "Demo vehicle \u2014 replace with make, model, year and condition.", "photo": "", "featured": false, "created": 1776500000000}, {"id": "demo-5", "title": "Car Rental \u2014 Daily", "category": "Car", "purpose": "For Rent", "price": 50000, "currency": "RWF", "location": "Rubavu", "details": "Demo rental rate \u2014 confirm the vehicle and daily rate before publishing.", "photo": "", "featured": false, "created": 1776400000000}];
const KEY="glpm_listings_v2";
function get(){const s=localStorage.getItem(KEY);if(s)return JSON.parse(s);localStorage.setItem(KEY,JSON.stringify(window.DEFAULT_LISTINGS));return window.DEFAULT_LISTINGS}
function save(a){localStorage.setItem(KEY,JSON.stringify(a))}
function money(n,c){return new Intl.NumberFormat("en-US").format(n)+" "+c}
function render(){
 const a=get(); document.getElementById("adminCount").textContent=`${a.length} listings`;
 document.getElementById("adminList").innerHTML=a.sort((x,y)=>y.created-x.created).map(x=>`<div class="admin-item"><div class="admin-thumb" ${x.photo?`style="background-image:url('${x.photo.replaceAll("'","%27")}')"`:""}>${x.photo?"":"PHOTO"}</div><div><h3>${esc(x.title)}</h3><p>${x.category} • ${x.purpose} • ${money(x.price,x.currency)}</p><p>📍 ${esc(x.location)}</p></div><div class="admin-buttons"><button class="edit" onclick="editItem('${x.id}')">Edit</button><button class="delete" onclick="deleteItem('${x.id}')">Delete</button></div></div>`).join("")||"<p>No listings yet.</p>";
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
window.editItem=id=>{const x=get().find(v=>v.id===id);if(!x)return;document.getElementById("editId").value=x.id;document.getElementById("title").value=x.title;document.getElementById("cat").value=x.category;document.getElementById("pur").value=x.purpose;document.getElementById("price").value=x.price;document.getElementById("currency").value=x.currency;document.getElementById("loc").value=x.location;document.getElementById("details").value=x.details;document.getElementById("photo").value=x.photo||"";document.getElementById("featured").checked=!!x.featured;document.getElementById("formTitle").textContent="Edit Listing";scrollTo({top:0,behavior:"smooth"})}
window.deleteItem=id=>{if(confirm("Delete this listing?")){save(get().filter(x=>x.id!==id));render()}}
document.addEventListener("DOMContentLoaded",()=>{
 if(!localStorage.getItem(KEY))save(window.DEFAULT_LISTINGS);
 render();
 document.getElementById("listingForm").addEventListener("submit",async e=>{
   e.preventDefault();
   const file=document.getElementById("photoFile").files[0];
   let photo=document.getElementById("photo").value.trim();
   if(file) photo=await readFile(file);
   const a=get(), id=document.getElementById("editId").value;
   const obj={id:id||"l-"+Date.now(),title:document.getElementById("title").value.trim(),category:document.getElementById("cat").value,purpose:document.getElementById("pur").value,price:Number(document.getElementById("price").value),currency:document.getElementById("currency").value,location:document.getElementById("loc").value.trim(),details:document.getElementById("details").value.trim(),photo,featured:document.getElementById("featured").checked,created:Date.now()};
   const idx=a.findIndex(x=>x.id===obj.id); if(idx>=0)a[idx]=obj;else a.push(obj); save(a); e.target.reset();document.getElementById("editId").value="";document.getElementById("formTitle").textContent="Add Listing";render();alert("Listing saved.");
 });
 document.getElementById("cancelEdit").onclick=()=>{document.getElementById("listingForm").reset();document.getElementById("editId").value="";document.getElementById("formTitle").textContent="Add Listing"};
 document.getElementById("resetBtn").onclick=()=>{if(confirm("Reset all listings to demo data?")){save(window.DEFAULT_LISTINGS);render()}};
});
function readFile(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
