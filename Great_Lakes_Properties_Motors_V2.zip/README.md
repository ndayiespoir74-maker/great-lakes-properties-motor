# Great Lakes Properties & Motors Ltd — Website V2

This version includes:
- Live client-side listing search
- Filters by category, rent/sale and location
- Price sorting
- Property and vehicle listing cards
- WhatsApp enquiry buttons
- Admin dashboard at `admin.html`
- Add / edit / delete listings
- Photo URL support
- Local photo upload support
- Responsive mobile design

IMPORTANT:
The included listings are DEMO records, clearly marked in their descriptions. They are not claimed to be actual inventory. Replace them in the Admin Dashboard with the company's real properties and vehicles.

The dashboard currently stores data in browser localStorage. That means changes are local to the browser/device. For a real online business website where staff can log in and all customers see the same listings, the next step is to connect the dashboard to a database and secure authentication (for example Supabase/Firebase or a custom backend).

Contact configured:
Phone/WhatsApp: 0786365133
Email: greatlakespropertiesmotors@gmail.com
Location: Rubavu, Western Province, Rwanda
